#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
#include "srt.h"
using namespace std;

void menu();
void division();

int main()
{
    // display welcom screen
    menu();

    //perform SRT division
    division();
    return 0;
}


/// <summary>
/// menu()
/// - This function displays the welcom screen for this simulator
/// </summary>
void menu()
{
    int choice;
    cout << "//////////////////////////////////////////////////////////\n";
    cout << "////             Welcome to SRT Simulator             ////\n";
    cout << "//////////////////////////////////////////////////////////\n\n\n";
}

/// <summary>
/// division()
/// - This function runs the SRT simulatiation and generates a graph of the 
///     results
/// </summary>
void division()
{
    int deltaT[11];
    deltaT[0] = srt(0xde, 0xe, 4).deltaT;
    deltaT[1] = srt(0x19, 0x5, 4).deltaT;
    deltaT[2] = srt(0xcd, 0xa, 4).deltaT;
    deltaT[3] = srt(0x156, 0b101110, 6).deltaT;
    deltaT[4] = srt(0x232, 0b011111, 6).deltaT;
    deltaT[5] = srt(0x1111, 0x22, 8).deltaT;
    deltaT[6] = srt(0x3333, 0x11, 8).deltaT;
    deltaT[7] = srt(0x5ac2, 0x79, 8).deltaT;
    deltaT[8] = srt(0x9cde11, 0xabc, 12).deltaT;
    deltaT[9] = srt(0x672300, 0xdef, 12).deltaT;
    deltaT[10] = srt(0xabcdef, 0x987, 12).deltaT;
    
    double avg = 0;
    for(int i = 0; i < 11; i++){
        avg += deltaT[i];
    }
    avg = avg/11.0;
    cout << "Average execution time: " << avg << "\u0394t\n\n";
    

    double dtp[12];
    int ol[11];
    ol[0] = 4;
    ol[1] = 4;
    ol[2] = 4;
    ol[3] = 6;
    ol[4] = 6;
    ol[5] = 8;
    ol[6] = 8;
    ol[7] = 8;
    ol[8] = 12;
    ol[9] = 12;
    ol[10] = 12;

    for(int i = 0; i < 11; i++){
        dtp[i] = deltaT[i]/4;
    }
    dtp[11] = avg/4;

    cout << "Operand Lenght |\n";

    for(int i = 0; i < 11; i++){
        cout << right << setw(14) << setfill(' ') << ol[i] << " | " <<  deltaT[i] << "\u0394t\t";
        for(int j = 0; j < dtp[i]; j++){
            cout << "\u2588";
        }
        cout << endl;
    }
    cout.precision(3);
    cout << right << setw(14) << setfill(' ') << "Average" << " | " << avg << "\u0394t\t";
    for(int j = 0; j < dtp[11]; j++){
        cout << "\u2588";
    }
    cout << endl << endl;
}

