#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
#include "srt.h"
using namespace std;

int shift_count = 0;       //measures if the program should end


/// <summary>
/// srt()
/// - Simulates binary division using the SRT method
/// - param a: Dividend
/// - param b: Divisor
/// - param length: length of Divisor
/// </summary>
srt::srt(unsigned int a, unsigned int b, unsigned int length)
{
    cout << "A = .";
    binary_print(a, length * 2);
    cout << "\tB =  .";
    binary_print(b, length);
    cout << endl;

    unsigned int pre = AQ_Less(a, b, length);   //checks/makes sure AQ is less than B. pre = the number of places a was shifted to be made smaller than b
    unsigned int norm = normalize(b, length);   //normalizes B, norm = the number of places normalized
    unsigned int negb = negative(b, length);    //negb = the negative of normalized B
    shift_count = -norm +1 ;                    //adjusts for the amount of spaces needed to be normalized
    
    cout << right << setw(length*2+5) << setfill(' ') << "Normalized" << "\tB =  .";
    binary_print(b,length);                     //prints value in binary
    cout << "\n" << right << setw(length*2+5) << setfill(' ') << "-Normalized" << "\tB = 1.";
    binary_print(negative_print(b,length),length);
    cout << "\n\n";
    cout << "\t\t" << left << setw(length*2 + 2) << "AQ" <<endl;
    cout << "\t\t" << setw(length*2+2) << setfill('-') << "-" << endl;
    cout << "initialize AQ\t";
    binary_print_with_decimal(a,length*2+1);

    a = adjust(a,norm);                         //adjusts AQ for normalization factor

    cout << "\nAdj AQ\t\t";
    binary_print_with_decimal(a,length*2+1);

    shift0s(a,length);                          //shifts over 0's
    cout << "\nshfOvr 0's\t";
    binary_print_with_decimal(a,length*2+1);
    cout << endl;
    sub(a,negb, length);                        //subtracts B from AQ

   while(shift_count < length + 2  )            //main loop that repeats while the shift_count is below threshold
   {
    bool pos = shiftAQ(a,length);               //true means the shift AQ function was positive

    if(pos == true)                             //if positive then run this
    {
        cout << "SHL AQ, Q0=1\t";
        binary_print_with_decimal(a,length*2+1);
        deltaT += 3;
        cout << endl;

        if(shift_count < length + 2   )         //checks for end of program
        {
            cout << "ShfOvr 0's\t";
            shift0s(a,length);
            binary_print_with_decimal(a,length*2+1);
            cout << endl;
        }

        if(shift_count < length + 2   )         //checks for end of program
        {
            sub(a,negb,length);
        }
    }
    else                                        //if negative run this
    {
        cout << "SHL AQ, Q0=0\t";
        binary_print_with_decimal(a,length*2+1);
        cout << endl;
        deltaT += 3;
        
        if(shift_count < length + 2   )         //checks for end of program
        {
            cout << "ShfOvr 1's\t";
            shift1s(a, length);
            binary_print_with_decimal(a,length*2+1);
            cout << endl;
        }
        if(shift_count < length + 2  )          //checks for end of program
        {
            add(a,b,length);
        }
    }
   }

   unsigned int x=1;                            //used to grab quotient using mask
   for(int i =0; i < length ; i++)
   {
       x = x << 1;
       x++;
   }

    unsigned int quotient = a & x;                //uses and mask to grab quotient

   if(a >=pow(2,length*2))                        //adjusts for if AQ is negative
   {
       deltaT += 3;                               //delta T of shift opperation.
       a = a >> 1;
       a += pow(2,length*2);
        cout << "SHR A\t\t";
        binary_print_with_decimal(a,length*2+1);
        cout << endl;

        add(a,b,length);
        a = a << 1;
   }
    a = a >> length + norm +1;                    //converts AQ into remainder

    cout << "Q = ";
    binary_print_with_decimal(quotient, length+1);


    cout <<"\nR = ";
    binary_print(a,length);
    cout << endl;

    cout << "Execution Time = " << deltaT << "\u0394t\n";
    cout << "---------------------------------------------\n\n";
}

/// <summary>
/// normalize()
/// - This function normalizes B
/// - param b: Divisor
/// - param length: length of Divisor
/// </summary>
unsigned int srt::normalize(unsigned int &b,double length)
{
    unsigned int c =0;
    while (b < pow(2, length-1))
    {
        deltaT += 3;    //delta T of shift opperation.
        b = b << 1;
        c++;
    }
    return c;
}

/// <summary>
/// binary_print()
/// - This function prints the value of an unsigned interger in binary
///     the the screen.
/// - param a: int to be printed to the screen
/// - param length: length of a
/// </summary>
void srt::binary_print(unsigned int a, double length)
{
    int low = pow(2, length-1);
    int high = low *2;
    for(int i = 0; i < length; i++)
    {
        if(a >= low && a < high)
        {
            cout << 1;
            a = a - low;
        }
        else{
            cout <<0;
        }
        a = a <<1;
    }
}

/// <summary>
/// binary_print_with_decimal()
/// - This function prints the value of an unsigned interger in binary
///     the the screen with a decimal after the MSB.
/// - param a: int to be printed to the screen
/// - param length: length of a
/// </summary>
void srt::binary_print_with_decimal(unsigned int a, double length)
{
    int low = pow(2, length-1);
    int high = low *2;
    //cout <<low <<" " << high << " " << a <<endl;
    for(int i = 0; i < length; i++)
    {
        if(i == 1){
            cout << '.';
        }
        if(a >= low && a < high)
        {
            cout << 1;
            a = a - low;
        }
        else{
            cout <<0;
        }
        a = a <<1;
    }
}

/// <summary>
/// nagativer()
/// - This function uses 2's compliment to get the nagative value
///     of a unsigned integer.
/// - param a: integer to be converted to a negetive
/// - param length: length of a
/// </summary>
unsigned int srt::negative(unsigned int a, double length)
{
    deltaT = deltaT + length;               // Calculate delta T for 2's compliment operation.
    unsigned int b = pow(2, length+1) - 1; // bottom n +1 digits = 1
    b = b ^ a;
    b++;
    return b;
}

/// <summary>
/// negative_print()
/// - This function prints the negativ value of an unsigned interger in binary
///     using 2's compliment to the the screen.
/// - param a: int to be printed to the screen
/// - param length: length of a
/// </summary>
unsigned int srt::negative_print(unsigned int a, double length)
{
    unsigned int b = pow(2, length) - 1; // bottom n +1 digits = 1
    b = b ^ a;
    b++;
    return b;
}

/// <summary>
/// adjust()
/// - This function shifts AQ to match B after it has been
///     normalized.
/// - param a: integer to be shifted
/// - param shift: the number of times B was shifted during 
///                normilization.
/// </summary>
unsigned int srt::adjust(unsigned int a, unsigned int shift)
{
    a = a << shift;
    shift_count +=shift;
    deltaT += 3;    //delta T of shift opperation.
    return a;
}


/// <summary>
/// AQ_Less()
/// - This function increases the size of AQ and realigns B to
///     prevent loss of data.
/// - param a: contents of AQ registers
/// - param b: contents of B registers
/// - param length: length of B register
/// </summary>
unsigned int srt::AQ_Less(unsigned int &a, unsigned int b, unsigned int &length)
{
    b = b << length;
    unsigned int c=0;
    while(a > b)
    {
        length += 1;        //this will increase the size of AQ but prevent the loss of data
        b = b << 1;         //this realigns B with AQ for an accurate compare
        deltaT += 3;        //delta T of shift opperation.
        c++;
    }
    return c;
}


/// <summary>
/// shift0s()
/// - This function shifts AQ left inserting 0's
/// - param a: contents of AQ registers
/// - param length: length of B register
/// </summary>
void srt::shift0s(unsigned int &a,double length)
{
    bool out=false;
    while(a < pow(2, length*2-1) && out == false)
    {
        if(shift_count < length+2)
            {
            a = a << 1;
            shift_count++;
            deltaT += 3;    //delta T of shift opperation.
        }
        else{out = true;}
    }
}

/// <summary>
/// shift0s()
/// - This function shifts AQ left inserting 1's
/// - param a: contents of AQ registers
/// - param length: length of B register
/// </summary>
void srt::shift1s(unsigned int &a,double length)
{
    bool out=false;
    while(a >= pow(2, length*2)+ pow(2,length*2 -1) && out == false)
    {
        if(shift_count < length+2)
            {
            a -= pow(2, length*2);
            a = a <<1;
            shift_count++;
            a++;
            deltaT += 3;    //delta T of shift opperation.
        }
        else{out = true;}
    }
}


/// <summary>
/// shiftAQ()
/// - This function shifts AQ left and returns weather AQ
///     is pos or negative
/// - param a: contents of AQ registers
/// - param length: length of B register
/// </summary>
bool srt::shiftAQ(unsigned int &a, double length)
{
    deltaT += 3;        //delta T of shift opperation.
    bool pos;
    if (a <= pow(2,length*2)-1)
    {
        a = a << 1;
        shift_count++;
        a++;
        pos = true;
    }
    else
    {
        a = a <<1;
        a-= pow(2, length*2+1);
        shift_count++;
        pos = false;
    }
    return pos;
}

/// <summary>
/// sub()
/// - This function adds negative normalized B to the contents of AQ
/// - param a: contents of AQ registers
/// - param negb: the value of negative B
/// - param length: length of B register
/// </summary>
void srt::sub(unsigned int &a, unsigned int negb, int length)
{
    cout << "Sub B\t\t";
    binary_print_with_decimal(negb,length+1);
    cout << "\n\t\t" << setw(length*2+2) << setfill('-') << "-" << endl;

    deltaT = deltaT + (10 + 2 * ceil((length-4.0)/4.0));    //Calculate delta T for carry select adder.

    negb = negb << length;
    a = a+negb;
    if (a >= pow(2, length*2+1))
    {
        a-= pow(2, length*2+1);
    }

    if ((a >> length*2) && 1U){
        cout << "Neg Rslt\t";
        binary_print_with_decimal(a, length*2+1);
        cout << endl;
    }else{
        cout << "Pos Rslt\t";
        binary_print_with_decimal(a, length*2+1);
        cout << endl;
    }
}

/// <summary>
/// add()
/// - This function adds the normalized value of B to the contents of AQ
/// - param a: contents of AQ registers
/// - param normb: the value of normalized B
/// - param length: length of B register
/// </summary>
void srt::add(unsigned int &a, unsigned int normb, int length)
{
    cout << "Add B\t\t";
    binary_print_with_decimal(normb,length+1);
    cout << "\n\t\t" << setw(length*2+2) << setfill('-') << "-" << endl;
    
    deltaT = deltaT + (10 + 2 * ceil((length-4.0)/4.0));    //Calculate delta T for carry select adder.

    normb = normb << length;
    a = a+normb;
    if (a >= pow(2, length*2+1))
    {
        a-= pow(2, length*2+1);
    }

    if ((a >> length*2) && 1U){
        cout << "Neg Rslt\t";
        binary_print_with_decimal(a, length*2+1);
        cout << endl;
    }else{
        cout << "Pos Rslt\t";
        binary_print_with_decimal(a, length*2+1);
        cout << endl;
    }
}
