#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <math.h>
#pragma once
using namespace std;

class srt{
    public:
        srt(unsigned int a, unsigned int b, unsigned int length);
        int deltaT = 0;
    private:
        int shift_count = 0;
        unsigned int normalize(unsigned int &b, double length);
        void binary_print(unsigned int a, double length);
        void binary_print_with_decimal(unsigned int a, double length);
        unsigned int negative(unsigned int a, double length);
        unsigned int adjust(unsigned int a, unsigned int shift);
        unsigned int AQ_Less(unsigned int &a, unsigned int b, unsigned int &length);
        unsigned int negative_print(unsigned int a, double length);
        void shift0s(unsigned int &a,double length);
        void shift1s(unsigned int &a,double length);
        bool shiftAQ(unsigned int &a, double length);
        void sub(unsigned int &a, unsigned int negb, int length);
        void add(unsigned int &a, unsigned int normb, int length);
};